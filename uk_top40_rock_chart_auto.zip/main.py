
import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import os

# URL de la page Official Charts Rock & Metal
url = "https://www.officialcharts.com/charts/rock-and-metal-albums-chart/"

# Requête HTML
headers = {"User-Agent": "Mozilla/5.0"}
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text, "html.parser")

# Sélecteurs pour les titres et artistes (structure connue du site)
entries = soup.select(".chart-positions li")

top = []
for idx, entry in enumerate(entries[:40], 1):
    album = entry.select_one(".title")
    artist = entry.select_one(".artist")
    album_name = album.text.strip() if album else "N/A"
    artist_name = artist.text.strip() if artist else "N/A"

    top.append({
        "position": idx,
        "album": album_name,
        "artist": artist_name
    })

# Sauvegarde du JSON
os.makedirs("data", exist_ok=True)
with open("data/top40.json", "w", encoding="utf-8") as f:
    json.dump(top, f, ensure_ascii=False, indent=2)

# Génération du bandeau HTML
with open("top40-bandeau.html", "w", encoding="utf-8") as f:
    f.write("<!DOCTYPE html><html lang='fr'><head><meta charset='UTF-8'><title>Top 40 Rock Metal UK</title><style>")
    f.write("body{margin:0;background:#111;color:#fff;font-family:sans-serif;font-size:16px;}")
    f.write(".wrapper{display:flex;align-items:center;overflow:hidden;white-space:nowrap;border-top:2px solid red;border-bottom:2px solid red;background:#000;padding:10px}")
    f.write(".label{background:red;color:white;font-weight:bold;padding:5px 15px;margin-right:15px}")
    f.write(".scroll{animation:scroll 60s linear infinite;display:inline-block}@keyframes scroll{0%{transform:translateX(100%)}100%{transform:translateX(-100%)}}</style></head><body>")
    f.write("<div class='wrapper'><div class='label'>TOP UK ROCK</div><div class='scroll'>")
    f.write(" | ".join([f"#{e['position']} {e['artist']} – {e['album']}" for e in top]))
    f.write("</div></div></body></html>")
